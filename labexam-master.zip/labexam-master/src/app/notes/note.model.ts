export interface Note {
  id: string,
  name: string;
  adNumber: number;
  offense: string;
  amount: number;
}
